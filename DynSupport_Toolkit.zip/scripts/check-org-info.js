document.addEventListener("DOMContentLoaded", async () => {
  const crmBaseUrl = getCrmBaseUrlFromQuery();
  const table = document.getElementById("orgTable");
  let orgData = null;

  try {
    const result = await fetchCrmData("organizations", crmBaseUrl);
    orgData = result.value?.[0] || result;
    renderKeyValueTables(result.value, table);
  } catch (err) {
    table.innerHTML = "<tr><td>Error loading data: " + err.message + "</td></tr>";
  }

  document.getElementById("exportBtn").addEventListener("click", () => {
    if (orgData) {


    crmName = crmBaseUrl.replace(/^https?:\/\//i, ''); 
    let filename = `org_settings_${crmName}}`;
    exportAsTxt(orgData, filename);
    }
  });
});
