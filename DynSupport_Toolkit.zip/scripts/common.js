// get Base URL
function getCrmBaseUrlFromQuery() {
  const params = new URLSearchParams(window.location.search);
  const fullUrl = params.get("crmUrl");
  if (!fullUrl) throw new Error("CRM URL not passed to this page.");

 // Find the position of "/main.aspx" in the URL
  const index = fullUrl.toLowerCase().indexOf("/main.aspx");

  if (index === -1) {
    throw new Error("Current URL is not support, please start from an App, current URL is : "+fullUrl);
  }

  // Extract the part of the URL before "/main.aspx"
  const baseUrl = fullUrl.substring(0, index);
  return baseUrl;
}

// export json to file
function exportAsTxt(data, filename = "data.txt") {
  const blob = new Blob([JSON.stringify(data, null, 2)], { type: "text/plain;charset=utf-8;" });
  const url = URL.createObjectURL(blob);
  const a = document.createElement("a");
  a.href = url;
  a.download = filename+getCurrentTimestamp()+'.txt';
  a.click();
  URL.revokeObjectURL(url);
}


function renderKeyValueTables(dataArray, container) {
    container.innerHTML = ""; // clear existed data
  
    if (!Array.isArray(dataArray) || dataArray.length === 0) {
      container.innerHTML = "<p>No data to display.</p>";
      return;
    }
  
    dataArray.forEach((item, index) => {
      const table = document.createElement("table");
      table.border = "1";
      table.style.marginBottom = "20px";
      table.style.borderCollapse = "collapse";
      table.style.width = "100%";
  
      const caption = document.createElement("caption");
      caption.textContent = `Record ${index + 1}`;
      caption.style.fontWeight = "bold";
      caption.style.marginBottom = "5px";
      table.appendChild(caption);
  
      const thead = document.createElement("thead");
      thead.innerHTML = "<tr><th>Key</th><th>Value</th></tr>";
      table.appendChild(thead);
  
      const tbody = document.createElement("tbody");
  
      Object.entries(item).forEach(([key, value]) => {
        const row = document.createElement("tr");
  
        const keyCell = document.createElement("td");
        keyCell.textContent = key;
        keyCell.style.padding = "4px";
  
        const valueCell = document.createElement("td");
        valueCell.textContent = value === null ? "null" : value.toString();
        valueCell.style.padding = "4px";
  
        row.appendChild(keyCell);
        row.appendChild(valueCell);
        tbody.appendChild(row);
      });
  
      table.appendChild(tbody);
      container.appendChild(table);
    });
  }
  


// query date function
async function fetchCrmData(endpoint, crmBaseUrl) {
  const fullUrl = `${crmBaseUrl}/api/data/v9.0/${endpoint}`;

  try {
    const response = await fetch(fullUrl, {
      method: "GET",
      headers: {
        "Accept": "application/json",
        "OData-Version": "4.0"
      },
      credentials: "include"
    });

    if (!response.ok) {
      throw new Error(`Fetch failed: ${response.status} ${response.statusText}`);
    }

    return await response.json();

  } catch (error) {
    console.error("Error during fetchCrmData:", error);
    throw error;
  }
}

function getCurrentTimestamp() {
  const now = new Date();
  const pad = (n) => n.toString().padStart(2, '0');

  const month = pad(now.getMonth() + 1);
  const day = pad(now.getDate());

  const hour = pad(now.getHours());
  const minute = pad(now.getMinutes());

  return `_${month}${day}_${hour}${minute}`;
}
