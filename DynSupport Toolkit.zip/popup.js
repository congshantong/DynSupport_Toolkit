document.addEventListener("DOMContentLoaded", () => {
  // Map each button ID to its corresponding feature page path
  const featureMap = {
    "btnCheckSolutionLayer": "pages/check-solution-layer.html",
    "btn-check-solution-version": "pages/check-solution-version.html",
    "btn-check-flow-callback": "pages/check-flow-callback.html",
    "checkOrgInfoBtn": "pages/check-org-info.html"
  };

  // Add event listener for each button
  for (const [btnId, pagePath] of Object.entries(featureMap)) {
    const button = document.getElementById(btnId);
    if (button) {
      button.addEventListener("click", () => openFeaturePage(pagePath));
    }
  }
});

/**
 * Opens a new tab with the feature page and appends the current CRM URL as a query parameter
 * @param {string} relativePath - The relative path to the feature page
 */
async function openFeaturePage(relativePath) {
  const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
  const crmUrl = encodeURIComponent(tab.url);
  const pageUrl = chrome.runtime.getURL(`${relativePath}?crmUrl=${crmUrl}`);
  chrome.tabs.create({ url: pageUrl });
}
