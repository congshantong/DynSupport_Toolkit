let layerData = [];

document.addEventListener("DOMContentLoaded", () => {
  loadTypeOptions();
  const crmBaseUrl = getCrmBaseUrlFromQuery();

  document.getElementById("checkBtn").addEventListener("click", async () => {
    const logicalName = document.getElementById("type").value;
    const id = document.getElementById("id").value.trim();
    const resultEl = document.getElementById("result");

    if (!logicalName || !id) {
      resultEl.textContent = "Component Type and ID are required.";
      return;
    }

    resultEl.textContent = "Fetching...";

    try {
      //const crmBaseUrl = getCrmBaseUrlFromQuery();
      const encodedId = encodeURIComponent(id);
      const encodedName = encodeURIComponent(logicalName);

      const data = await fetchCrmData(
        `msdyn_componentlayers?$filter=(msdyn_componentid eq ${encodedId} and msdyn_solutioncomponentname eq '${encodedName}')`,
        crmBaseUrl
      );

      layerData = data;

      const sorted = data.value.sort((a, b) => b.msdyn_order - a.msdyn_order);

      let tableHtml = `
        <table>
          <thead>
            <tr>
              <th>Order</th>
              <th>Solution Name</th>
              <th>Publisher Name</th>
              <th>Overwrite Time</th>
            </tr>
          </thead>
          <tbody>
      `;

      sorted.forEach(item => {
        tableHtml += `
          <tr>
            <td>${item.msdyn_order}</td>
            <td>${item.msdyn_solutionname}</td>
            <td>${item.msdyn_publishername}</td>
            <td>${item.msdyn_overwritetime}</td>
          </tr>
        `;
      });

      tableHtml += "</tbody></table>";
      resultEl.innerHTML = tableHtml;

    } catch (err) {
      resultEl.textContent = "Error: " + err.message;
    }
  });

  document.getElementById("exportLayerInfoBtn").addEventListener("click", () => {

    crmName = crmBaseUrl.replace(/^https?:\/\//i, ''); 
    let filename = `layer_info_${crmName}`;
    exportAsTxt(layerData, filename);
  });
});

async function loadTypeOptions() {
  const typeSelect = document.getElementById("type");
  try {
    const res = await fetch("../config/type-config.json");
    const types = await res.json();

    types.forEach(type => {
      const option = document.createElement("option");
      option.value = type.logicalName;
      option.textContent = type.name;
      typeSelect.appendChild(option);
    });
  } catch (e) {
    console.error("Failed to load type config:", e);
    const fallback = document.createElement("option");
    fallback.textContent = "Failed to load types";
    typeSelect.appendChild(fallback);
  }
}
