document.addEventListener("DOMContentLoaded", () => {
  const crmUrl = getCrmBaseUrlFromQuery();
  const input = document.getElementById("flowInput");
  const queryBtn = document.getElementById("queryBtn");
  const exportBtn = document.getElementById("exportBtn");
  const resultsDiv = document.getElementById("results");

  let workflowResult = null;
  let callbackResult = null;

  queryBtn.addEventListener("click", async () => {
    const para = input.value.trim();
    if (!para) {
      alert("Please enter a Flow name or ID.");
      return;
    }

    const isGuid = /^[0-9a-fA-F]{8}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{12}$/.test(para);
    const filter = isGuid
      ? `workflowidunique eq '${para}' or resourceid eq '${para}' or workflowid eq '${para}'`
      : `name eq '${para}'`;

    try {
      const workflowJson = await fetchCrmData(`workflows?$filter=${encodeURIComponent(filter)}`, crmUrl);
      workflowResult = workflowJson;

      if (!workflowJson.value || workflowJson.value.length === 0) {
        resultsDiv.innerHTML = "<p>No matching workflow found.</p>";
        return;
      }

      if (workflowJson.value.length > 1) {
        resultsDiv.innerHTML = "<p>Error: Multiple workflows found. Please enter a more specific Flow name or ID.</p>";
        return;
      }

      const workflowId = workflowJson.value[0].workflowid;
      const callbackJson = await fetchCrmData(`callbackregistrations?$filter=name eq '${workflowId}'`, crmUrl);
      callbackResult = callbackJson;

      renderKeyValueTables(callbackJson.value, resultsDiv);

    } catch (err) {
      console.error("Error querying data:", err);
      resultsDiv.innerHTML = "<p>Error querying data.</p>";
    }
  });

  exportBtn.addEventListener("click", () => {
    if (!workflowResult && !callbackResult) {
      alert("No data to export.");
      return;
    }
    const exportContent = {
      workflow: workflowResult,
      callback: callbackResult
    };

  crmName = crmUrl.replace(/^https?:\/\//i, ''); // ignore case.
  let filename = `flow_callback_${crmName}`;
  exportAsTxt(exportContent, filename);
  });
});
