let operationTypes = {};

document.addEventListener("DOMContentLoaded", () => {
  const crmBaseUrl = getCrmBaseUrlFromQuery();

  const input = document.getElementById("solutionName");
  const button = document.getElementById("btn-query-solution-version");
  const resultDiv = document.getElementById("versionResultTable");
  let solution_info=null;

  button.addEventListener("click", async () => {
    const name = input.value.trim();
    if (!name) {
      alert("Please enter a solution name.");
      return;
    }

    loadSolutionOptionsType();
    const apiUrl = `msdyn_solutionhistories?$filter=(msdyn_name eq '${name}')&$orderby=msdyn_starttime desc`;
    resultDiv.innerHTML = "Querying...";

    try {
      const data = await fetchCrmData(apiUrl, crmBaseUrl);
      solution_info = data;

      if (!data.value || data.value.length === 0) {
        resultDiv.innerHTML = "<p>No matching solution found.</p>";
        return;
      }

      renderTable(data.value);
    } catch (error) {
      console.error("Error:", error);
      resultDiv.innerHTML = "<p>Error querying solution data.</p>";
    }
  });


  document.getElementById("exportSolutionInfoBtn").addEventListener("click", () => {

    crmName = crmBaseUrl.replace(/^https?:\/\//i, ''); 
    let filename = `solution_history_${crmName}`;
    exportAsTxt(solution_info, filename);
  });

});


function renderTable(data) {
    const container = document.getElementById("versionResultTable");
    if (data.length === 0) {
      container.innerHTML = "<p>No results found.</p>";
      return;
    }
  
    const table = document.createElement("table");
    table.innerHTML = `
      <thead>
        <tr>
          <th>Start Time</th>
          <th>End Time</th>
          <th>Version</th>
          <th>Publisher</th>
          <th>Operation</th>
          <th>Status</th>
          <th>Exception</th>
          <th>Total Time</th>
          <th>Activity ID</th>
        </tr>
      </thead>
      <tbody>
        ${data.map(row => `
          <tr>
            <td>${row.msdyn_starttime || ""}</td>
            <td>${row.msdyn_endtime || ""}</td>
            <td>${row.msdyn_solutionversion || ""}</td>
            <td>${row.msdyn_publishername || ""}</td>
            <td>${operationTypes[row.msdyn_operation] || row.msdyn_operation || ""}</td>
            <td>${row.msdyn_status || 0}</td>
            <td>${row.msdyn_exceptionmessage || ""}</td>
            <td>${row.msdyn_totaltime || ""}</td>
            <td>${row.msdyn_activityid || ""}</td>	
          </tr>
        `).join("")}
      </tbody>
    `;
    container.innerHTML = "";
    container.appendChild(table);
}

// Load solution opreation type
async function loadSolutionOptionsType() {
    try {
      const res = await fetch("../config/solution-operation-types.json");
      operationTypes = await res.json();
      console.log("Loaded operation types:", operationTypes);

    } catch (e) {
      console.error("Failed to load solution operation type config:", e);
      fallback.textContent = "Failed to load types";
    }
}
  
